package lesson03;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Muallif: Qudrat Abdurahimov
// Sana: 12.08.2023
// Maqsad: JTextField bilan tanishish
public class TextFieldFrame extends JFrame {
    JTextField textField1;
    JTextField textField2;
    JTextField textField3;

    JPasswordField passwordField;
    public TextFieldFrame(){
        super("JTextField bilan tanishish");
        setLayout(new FlowLayout());

        textField1 = new JTextField(10);
        add(textField1);

        textField2 = new JTextField("TextField-2");
        add(textField2);

        textField3 = new JTextField("TextField-3; o'zgartirilmaydi");
        textField3.setToolTipText("Bu matnni ozgartirish mumkin emas");
        textField3.setEditable(false);
        add(textField3);

        passwordField = new JPasswordField("gita", 10);
        passwordField.setToolTipText("Parolni kiriting");
        add(passwordField);

        Handler handler = new Handler();
        textField1.addActionListener(handler);
        textField2.addActionListener(handler);
        textField3.addActionListener(handler);
        passwordField.addActionListener(handler);
    }

    private class Handler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            String xabar = "";

            if (e.getSource() == textField1){
                xabar = String.format("TextField1: %s",
                        e.getActionCommand());
            }

            if (e.getSource() == textField2){
                xabar = String.format("TextField2: %s",
                        e.getActionCommand());
            }

            if (e.getSource() == textField3){
                xabar = String.format("TextField3: %s",
                        e.getActionCommand());
            }

            if (e.getSource() == passwordField){
                xabar = String.format("passwordField: %s",
                        e.getActionCommand());
            }

            JOptionPane.showMessageDialog(null, xabar);
        }
    }
}
