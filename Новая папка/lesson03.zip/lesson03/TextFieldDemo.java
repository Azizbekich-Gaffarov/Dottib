package lesson03;

import javax.swing.*;

// Muallif: Qudrat Abdurahimov
// Sana: 12.08.2023
// Maqsad: 
public class TextFieldDemo {
    public static void main(String[] args) {
        TextFieldFrame frame = new TextFieldFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200, 200);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
}
