<div align="center">
<h1><b>PDF BOT</b></h1>
</div>
<h3>DEMO</h3>
<p> Scan the QR code below</P>

![](https://raw.githubusercontent.com/manumanoj0010/PDF-BOT/main/share.jpeg)
<h5> or </h5>
<ul>
     <li>Open Telegram</li>
     <li>Search converter_pdf_bot </li>
</ul>
<div align="center">
     <h2>Features</h2>
 </div>
<h3>Images to PDF</h3>

     ◍ This bot will helps you to convert multiple images to pdf
     ◍ .jpg, .jpeg, .png files Supported
     ◍ Zero additional Compression
     ◍ For Better quality pdf, send media without Compression
     ◍ Image sequence will be considered
     ◍ /cancel - deletes the current queue
     ◍ you can Rename your pdf at the time of /generate
          - /generate name     {pdf with your name}
          - /generate          {pdf with your id}
          - /generate FileName {pdf with file name}
      ◍ /id to get your id

<h3 >PDF to images</h3>

     ◍ Unlike other bots, this bot extract images from your pdf files without converting the entire pdf to pages.
     ◍ You can also fetch a single image or a list of images from any part of your pdf 
     ◍ Sequence will be considered
     ◍ For better quality images, bot support sending images as documents (files)
     

<h3>Files to PDF</h3>

     In addition,
     ◍ About 40+ popular file formats can also be convert to pdf using ilovepdf bot
     ◍ By default, bot support with ASCII char. support [EPUB, FB2(e-book), XPS, openXPS, CBZ, CBR]
     ◍ All other files are converted using ConvertAPI [csv, doc, docx, ppt, pptx, dot, dotx, log, mpp, mpt, odt, pot, potx, pps, ppsx, pub, rtf, txt, vdx, vsd, vsdx, vst, vstx, wpd, wps, wri, xls, xlsb, xlsx, xlt, xltx, xml] & supports Unicode Char(utf-8)
     ◍ No need to specify file formats..✌️

<h3>Pdf to text</h3>

     ◍ Convert pdf to text, .txt file
     ◍ It also supports html(to view pdfs on browsers), json files

<h3 >Split pdf</h3>

     ◍ Now you can Split your pdf in to smaller Ones
     ◍ /extract start:end
     ◍ supports single pages too..

<h3>Encrypt pdf</h3>

    ◍ Pdf Encryption Supported
    ◍ /encrypt pdf

<h3>Commands:</h3>

     /start - Check wheather bot alive.
     /id - Get Ur Id (default pdf name)
     /cancel - Delete's old queue
     /generate - long tap to set a pdf name
     /extract - to get images from pdf
     /encrypt - pdf Encryption
     /text - converts pdf to text, .txt, html, json files

<h2 align="center">Privacy & Security:</h2>

     Ones the necessary task is completed, all your images including the pdf file will be removed from the server.
 <h3>Made with ❤ by Manoj & Swetha</h3>
