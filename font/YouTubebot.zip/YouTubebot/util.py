import json
import dotenv
CONFIG = dotenv.dotenv_values(".env")

class MessagesDB:
    def __init__(self, language) -> None:
        self.language = language
        self.path = "./data/messages.db.json"
    def _read_data(self):
        with open(self.path, 'r') as f:
            return json.loads(f.read())
    def get_message(self, which):
        data = self._read_data()
        if which == 'start':
            for langs in data['start'].keys():
                if self.language == langs:
                    return data['start'][langs]
        elif which == 'reg':
            for langs in data['reg'].keys():
                if self.language == langs:
                    return data['reg'][langs]
        elif which == 'live_st_error':
            for langs in data['live_st_error'].keys():
                if self.language == langs:
                    return data['live_st_error'][langs]
        elif which == 'undefined_err':
            for langs in data['undefined_err'].keys():
                if self.language == langs:
                    return data['undefined_err'][langs]
        elif which == 'dn_desc':
            for langs in data['dn_desc'].keys():
                if self.language == langs:
                    return data['dn_desc'][langs]
        elif which == 'dn_err_desc':
            for langs in data['dn_err_desc'].keys():
                if self.language == langs:
                    return data['dn_err_desc'][langs]