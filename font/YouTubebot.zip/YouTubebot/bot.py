import datetime
import json
import os
import secrets
import requests
from telebot import TeleBot
from telebot.types import Message, InlineKeyboardButton, InlineKeyboardMarkup, PhotoSize
from util import CONFIG, MessagesDB
import pytube
from telebot.apihelper import ApiTelegramException
from pytube.exceptions import LiveStreamError
import shutil
from pytube import Stream
from hurry.filesize import size
class Bot:
    def __init__(self, bot: TeleBot) -> None:
        self.bot = bot


    def dn_video(self, msg: Message):
        data = DataHelper()
        self.bot.answer_callback_query(msg.id, "Ok")
        user = data.get_user(msg)
        if user['proccess']:
            url = user['proccess'][0]
            res = data.dn_video(msg, url, self.bot)

    def start(self, msg):
        user = UserHelper(msg, self.bot)
        data = DataHelper()
        if data.is_exists(msg):
            user.reply(data.get_message_by_lang(msg))
        else:
            markup = InlineKeyboardMarkup()
            en = InlineKeyboardButton("🇺🇸 EN", callback_data='en')
            uz = InlineKeyboardButton("🇺🇿 UZ", callback_data='uz')
            ru = InlineKeyboardButton("🇷🇺 RU", callback_data='ru')
            markup.row(en, ru)
            markup.add(uz)
            text = f'''🇺🇸 Select Language\n🇺🇿 Tilni tanlang\n🇷🇺 Выбрать язык'''
            user.send_message(text, markup=markup)
    def set_user(self, call):
        data = DataHelper()
        if data.is_exists(call):
            data.set_lang(call, call.data.lower())
        else:
            data.set_user(call, call.data)
        self.bot.answer_callback_query(call.id, f'{call.data.title()} Selected')
        self.bot.edit_message_text(data.get_message_by_lang(call, which='reg'), call.from_user.id, call.message.id)
    def set_lang(self, msg):
        user = UserHelper(msg, self.bot)
        markup = InlineKeyboardMarkup()
        en = InlineKeyboardButton("🇺🇸 EN", callback_data='en')
        uz = InlineKeyboardButton("🇺🇿 UZ", callback_data='uz')
        ru = InlineKeyboardButton("🇷🇺 RU", callback_data='ru')
        markup.row(en, ru)
        markup.add(uz)
        text = f'''🇺🇸 Select Language\n🇺🇿 Tilni tanlang\n🇷🇺 Выбрать язык'''
        user.send_message(text, markup=markup)
    def send_to_all(self, msg):
        data = DataHelper()
        user = UserHelper(msg, self.bot)
        if data.is_admin(msg):
            data.set_command('send_to_all')
            user.send_message("Send me message!")
    def message(self, msg: Message):
        data = DataHelper()
        user = UserHelper(msg, self.bot)
        if msg.content_type == 'photo':
            if data.is_admin(msg) and data.get_command() == "send_to_all":
                file_url = self.bot.get_file_url(msg.photo[-1].file_id)
                data.set_command('ready')
                for i in data.get_all_users():
                    try:
                        self.bot.send_photo(i['id'], requests.get(file_url).content, caption=f'<b>{msg.caption}</b>')
                    except ApiTelegramException as e:
                        pass
        else:
            data.request_to_down(msg.text, msg, self.bot)
            
class UserHelper:
    def __init__(self, msg: Message, bot: TeleBot) -> None:
        self.msg = msg
        self.bot = bot
    def reply(self, message):
        self.bot.reply_to(self.msg, message)
    def send_message(self, msg, markup=None):
        self.bot.send_message(self.msg.from_user.id, msg, reply_markup=markup)
class DataHelper:
    def __init__(self) -> None:
        self.root_path = "./data/db.json"
        self.initial = {
            "users":[],
            "blocked_users":[],
            "proccess":[]
        }

    def set_command(self, command: str):
        with open(self.root_path, 'r') as f:
            old  = json.loads(f.read())
        for i in old['users']:
            if i['id'] == int(CONFIG.get('ADMIN_ID')):
                i['command'] = command.lower()
        with open(self.root_path, 'w') as f:
            f.write(json.dumps(old))
    def get_command(self):
        with open(self.root_path, 'r') as f:
            data  = json.loads(f.read())
            for i in data['users']:
                if i['id'] == int(CONFIG.get('ADMIN_ID')):
                    return i['command']
    def set_user(self, msg: Message, lang):
        initial = {"id":msg.from_user.id, "proccess":[], "history":[], "language":lang.lower()}
        with open(self.root_path, 'r') as f:
            old  = json.loads(f.read())
        old['users'].append(initial)
        with open(self.root_path, 'w') as f:
            f.write(json.dumps(old))
    def get_user(self, msg: Message):
        with open(self.root_path, 'r') as f:
            data  = json.loads(f.read())
        users = data['users']
        user_id = msg.from_user.id
        for i in users:
            if user_id == i['id']:
                return i
    def is_exists(self, msg: Message):
        with open(self.root_path, 'r') as f:
            data  = json.loads(f.read())
        users = data['users']
        user_id = msg.from_user.id
        for i in users:
            if user_id == i['id']:
                return True
        return False
    def is_admin(self, msg: Message):
        user_id = msg.from_user.id
        if user_id == int(CONFIG.get('ADMIN_ID')):
            return True
        return False
    def set_lang(self, msg, lang):
        with open(self.root_path, 'r') as f:
            old  = json.loads(f.read())
        for i in old['users']:
            if i['id'] == msg.from_user.id:
                i['language'] = lang
        with open(self.root_path, 'w') as f:
            f.write(json.dumps(old))
        
    def get_message_by_lang(self, msg: Message, which='start'):
        user = self.get_user(msg)
        mDB = MessagesDB(user['language'])
        return mDB.get_message(which)
    def get_all_users(self):
        with open(self.root_path, 'r') as f:
            data  = json.loads(f.read())
        users = data['users']
        return users


    def make_vieo_desc(self, yt: pytube.YouTube):
        length = datetime.timedelta(seconds=yt.length)
        v_title = yt.title
        desc = yt.description

        res = f'<b>⏳ {length}\n\n{v_title}</b>'
        markup = InlineKeyboardMarkup()

        count = []

        for i in yt.streams:
            if i.resolution:
                if len(count) != 2:
                    count.append(InlineKeyboardButton(f'📹 {i.resolution} {size(i.filesize)}', callback_data=i.resolution+size(i.filesize)))
                else:
                    markup.row(count[0], count[1])
                    count = []
        return [res, markup]


    def request_to_down(self, yt_video_url, msg, bot: TeleBot):
        data = DataHelper()
        yt = pytube.YouTube(yt_video_url)
        res = data.make_vieo_desc(yt)

        with open(self.root_path, 'r') as f:
            data  = json.loads(f.read())
        for i in data['users']:
            if i['id'] == msg.from_user.id:
                i['proccess'] = [yt_video_url]
        with open(self.root_path, 'w') as f:
            f.write(json.dumps(data))
        bot.send_photo(msg.from_user.id, requests.get(yt.thumbnail_url).content, caption=res[0], reply_markup=res[1])

        # f = secrets.token_urlsafe(16)
        # output = "./.cache/"
        # os.mkdir("./.cache/"+f)
        # output += f + '/'
        # try:
        #     yt.streams.first().download(output_path=output)
        # except LiveStreamError:
        #     bot.reply_to(msg, data.get_message_by_lang(msg, which="live_st_error"))
        #     shutil.rmtree(output)
        #     return "bad"
        # except Exception as e:
        #     bot.reply_to(msg, data.get_message_by_lang(msg, which="undefined_err"))
        #     shutil.rmtree(output)
        #     return "bad"
        # return output

            # if d != 'bad':
            #     for i in os.scandir(d):
            #         if i.is_file():
            #             self.bot.send_video(msg.from_user.id, open(i.path, 'rb').read())
            # shutil.rmtree(d)
    
    def dn_video(self, msg, url, bot: TeleBot):
        data = DataHelper()
        f = secrets.token_urlsafe(16)
        output = "./.cache/"
        os.mkdir("./.cache/"+f)
        output += f + '/'

        yt = pytube.YouTube(url)
        # try:
        video = ''
        for i in yt.streams:
            if i.resolution:
                if i.resolution+size(i.filesize) == msg.data:
                    video = i
        if not video:
            bot.edit_message_caption(data.get_message_by_lang(msg, 'dn_err_desc'), msg.from_user.id, msg.message.id)
        else:
            bot.edit_message_caption(data.get_message_by_lang(msg, 'dn_desc'), msg.from_user.id, msg.message.id)
            # ! Download a video
            try:
                path = video.download(output_path=output)
                bot.send_video(msg.from_user.id, open(path, 'rb').read(), caption="Done", timeout=10000)
            except Exception as e:
                bot.send_message(msg.from_user.id, str(e))
            shutil.rmtree(output)
            bot.delete_message(msg.from_user.id, msg.message.id)