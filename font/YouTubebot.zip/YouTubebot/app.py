from util import CONFIG
from telebot import TeleBot
from bot import Bot
# from telebot.types import 
bot = TeleBot(CONFIG.get("BOT_TOKEN"), parse_mode='HTML')
b = Bot(bot)

@bot.message_handler(commands=['start'])
def start_h(msg):
    b.start(msg)

@bot.message_handler(commands=['setlang'])
def settlang_h(msg):
    b.set_lang(msg)

@bot.message_handler(commands=['sendtoall'])
def send_h(msg):
    b.send_to_all(msg)

@bot.message_handler(func=lambda message: True)
def message_h(msg):
    b.message(msg)

@bot.message_handler(content_types=['photo'])
def photo_h(msg):
    b.message(msg)
    
@bot.callback_query_handler(func=lambda call: call.data == 'uz' or call.data == 'en' or call.data == 'ru')
def language_hand(call):
    b.set_user(call)

@bot.callback_query_handler(func=lambda call: True)
def language_hand(call):
    b.dn_video(call)
    

if __name__ == "__main__":
    bot.infinity_polling()